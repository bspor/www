@extends('layouts.master')

@section('title')
@parent
:: ForumTemplate
@stop

@section('content')
{{ Form::open(array('url' => 'register_action')) }}
<h2 class="form-signup-heading">Please Register</h2>
 
    <ul>
        @foreach($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach
    </ul>
    <p>Username :</p>
    <p>{{ Form::text('username') }}</p>
    <p>Email :</p>
    <p>{{ Form::text('email') }}</p>
    <p>Password :</p>
    <p>{{ Form::password('password') }}</p>
    <p>Confirm Password :</p>
    <p>{{ Form::password('cpassword') }}</p>
    <p>{{ Form::submit('Submit') }}</p>
{{ Form::close() }}
@stop