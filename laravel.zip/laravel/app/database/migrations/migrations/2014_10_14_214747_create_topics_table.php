<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTopicsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{


		Schema::create('topics', function(Blueprint $table) 
		{
			$table->increments('id');
			$table->integer('user_id')->unsigned();
			$table->integer('forum_id')->unsigned();
			$table->enum('status', [
				'new', 
				'accepted', 
				'progressing', 
				'completed', 
				'invalid'
			]);
			$table->enum('priority', [
				'critial', 
				'high', 
				'normal', 
				'low'
			])->nullable();
			$table->enum('type', [
				'bug', 
				'enhancement', 
				'feature'
			])->nullable();
			$table->string('title', 255);
			$table->text('content');
			$table->string('slug', 255);
			$table->timestamps();
			$table->softDeletes();

			$table->foreign('forum_id')
				->references('id')
				->on('forums');

            $table->foreign('user_id')
            	->references('id')
            	->on('users_foreign');
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('topics');
	}

}
