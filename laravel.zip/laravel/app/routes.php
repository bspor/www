<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::get('/', 'HomeController@showWelcome');
Route::get('home', 'HomeController@showWelcome');
// Authentication
//Route::get('/login', function() {
//    return URL::full();
//});
Route::get('login', 'AuthController@showLogin');
Route::post('login', 'AuthController@postLogin');
Route::get('logout', 'AuthController@getLogout');
Route::get('forum', 'ForumController@index');



// Secure-Routes
Route::group(array('before' => 'auth'), function()
{
    Route::get('secret', 'HomeController@showSecret');
});

// =============================================
// API ROUTES ==================================
// =============================================
Route::group(array('prefix' => '/api'), function() {

	// since we will be using this just for CRUD, we won't need create and edit
	// Angular will handle both of those forms
	// this ensures that a user can't access api/create or api/edit when there's nothing there
	Route::resource('comment', 'CommentController', 
		array('only' => array('index', 'store', 'destroy')));
});

// =============================================
// REGISTRATION ROUTE ==========================
// =============================================
Route::get('register', 'RegisterController@index');


Route::post('register_action', 'RegisterController@store');
// =============================================
// CATCH ALL ROUTE =============================
// =============================================
// all routes that are not home or api will be redirected to the frontend
// this allows angular to route them
App::missing(function($exception)
{
	return View::make('index');
});