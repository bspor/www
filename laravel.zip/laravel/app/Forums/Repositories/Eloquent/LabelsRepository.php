<?php namespace ScubaClick\Forums\Repositories\Eloquent;

use ScubaClick\Forums\Models\Label;
use ScubaClick\Forums\Contracts\LabelsInterface;

class LabelsRepository implements LabelsInterface
{

}
