<?php namespace ScubaClick\Forums\Contracts;

interface LabelsInterface
{

}
