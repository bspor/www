var commentApp = angular.module('commentApp', ['mainCtrl', 'commentService']);
commentApp.config(function($interpolateProvider) {
  $interpolateProvider.startSymbol('%%');
  $interpolateProvider.endSymbol('%%');
});